<?php include('includes/header.php'); ?>
<main>
  <h2><?= $lang['alerts_title'] ?></h2>
  <div id="alerts"></div>
  <script>
    fetch('/data/alerts.json')
      .then(res => res.json())
      .then(data => {
        const container = document.getElementById('alerts');
        data.alerts.forEach(alert => {
          const div = document.createElement('div');
          div.innerHTML = `<h3>${alert.region}</h3><p>${alert.message}</p>`;
          container.appendChild(div);
        });
      });
  </script>
</main>
<?php include('includes/footer.php'); ?>