<?php include('includes/header.php'); ?>
<main>
  <section class="hero">
    <img src="/images/dra-3.jpg" alt="Disaster response scene" />
    <div class="alert-banner">
      <strong>ALERT:</strong> Hurricane warning in Region 4. See <a href="/alerts.php">Alerts</a>.
    </div>
  </section>
  <section class="mission">
    <h2><?= $lang['mission_title'] ?></h2>
    <p><?= $lang['mission_text'] ?></p>
  </section>
</main>
<?php include('includes/footer.php'); ?>