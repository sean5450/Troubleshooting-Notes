<?php include(__DIR__ . '/../lang/en.php'); ?>
<!DOCTYPE html>
<html>
<head>
  <title>DRA</title>
  <link rel="stylesheet" href="/css/styles.css">
</head>
<body>
  <header>
    <img src="/images/logo.png" alt="DRA Logo" style="height:60px; vertical-align:middle;">
    <h1 style="display:inline-block; margin-left:10px;">Disaster Response Agency</h1>
    <nav>
      <a href="/index.php">Home</a> |
      <a href="/alerts.php">Alerts</a> |
      <a href="/resources.php">Resources</a> |
      <a href="/news.php">News</a> |
      <a href="/contact.php">Contact</a>
    </nav>
  </header>
