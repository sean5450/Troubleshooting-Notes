const mineflayer = require('mineflayer')

// === CONFIG ===
const SERVER_HOST = '192.168.1.231' // <-- replace with your server’s IP
const SERVER_PORT = 25565          // default Minecraft port
const BASE_NAME  = 'WinBotWander'        // bot username prefix
// ==============

// Pick a random username for this bot instance
const username = BASE_NAME + Math.floor(Math.random() * 10000)

// Create the bot
const bot = mineflayer.createBot({
  host: SERVER_HOST,
  port: SERVER_PORT,
  username: username
})

// Log server chat to console
bot.on('chat', (username, message) => {
  if (username === bot.username) return
  console.log(`${username}: ${message}`)
})

// On spawn → teleport to random spot + start chatter + movement
bot.on('spawn', () => {
  console.log(`${bot.username} spawned!`)

  // Random teleport within +/-500 blocks of world spawn
  const x = Math.floor(Math.random() * 1000) - 500
  const z = Math.floor(Math.random() * 1000) - 500
  bot.chat(`/tp ${bot.username} ${x} 70 ${z}`)

  // Say hello
  bot.chat(`Hello! I am ${bot.username}`)

  // Chat every 60s
  setInterval(() => {
    bot.chat(`I am still online! - ${bot.username}`)
  }, 60000)

  // Start wandering
  wander()
})

// Simple wander function
function wander() {
  const { vec3 } = require('vec3')
  let i = 0
  setInterval(() => {
    try {
      const pos = bot.entity.position.offset(Math.cos(i) * 3, 0, Math.sin(i) * 3)
      bot.lookAt(pos)
      bot.setControlState('forward', true)
      setTimeout(() => bot.setControlState('forward', false), 1000)
      i += Math.PI / 2
    } catch (err) {
      console.error("Wander error:", err)
    }
  }, 5000)
}

// Error handling
bot.on('kicked', console.log)
bot.on('error', console.log)
