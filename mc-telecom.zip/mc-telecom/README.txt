#####Minecraft Install#####

1. Install Node.js  

# node-v22.19.0-x64.msi

2. Install Mineflayer

# npm init -y
# npm install .\mineflayer-4.33.0.tgz

3. Run Bot

node .\bot.js