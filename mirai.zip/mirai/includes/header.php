<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Mirai Holdings</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
  <header>
    <h1>Mirai Holdings</h1>
    <nav>
      <a href="/index.php">Home</a>
      <a href="/about.php">About</a>
      <a href="/services.php">Services</a>
      <a href="/contact.php">Contact</a>
      <?php if (!empty($_SESSION['admin'])): ?>
        <a href="/admin.php">Admin</a>
        <a href="/logout.php">Logout</a>
      <?php else: ?>
        <a href="/login.php">Login</a>
      <?php endif; ?>
    </nav>
  </header>
  <main>
