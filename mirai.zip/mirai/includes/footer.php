  </main>
  <footer><p>&copy; 2025 Mirai Holdings</p></footer>
</body>
</html>