<?php
$mysqli = new mysqli("localhost", "mirai_user", "password", "mirai_db");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>