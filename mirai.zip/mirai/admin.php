<?php
session_start();
require("includes/auth.php");

$content = json_decode(file_get_contents("data/content.json"), true);
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $content['homepage'] = $_POST['homepage'];
    file_put_contents("data/content.json", json_encode($content, JSON_PRETTY_PRINT));
}
?>
<?php include("includes/header.php"); ?>
<h2>Admin Panel</h2>
<form method="POST">
  <textarea name="homepage" rows="10" cols="80"><?= htmlentities($content['homepage']) ?></textarea><br>
  <button type="submit">Update</button>
</form>
<?php include("includes/footer.php"); ?>
