<?php include("includes/header.php"); ?>
<h1>Welcome to Mirai Holdings</h1>
<p>We build tomorrow’s financial foundation through strategic investment, risk-managed growth, and trusted partnerships.</p>
<?php include("includes/footer.php"); ?>
