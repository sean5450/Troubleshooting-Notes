<?php
session_start();
$valid_user = "admin";
$valid_pass = "secure123";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if ($_POST['username'] === $valid_user && $_POST['password'] === $valid_pass) {
        $_SESSION['admin'] = true;
        header("Location: admin.php");
        exit();
    } else {
        $error = "Invalid credentials";
    }
}
?>
<?php include("includes/header.php"); ?>
<h2>Admin Login</h2>
<?php if (!empty($error)) echo "<p>$error</p>"; ?>
<form method="POST">
  Username: <input name="username" /><br>
  Password: <input name="password" type="password" /><br>
  <button type="submit">Login</button>
</form>
<?php include("includes/footer.php"); ?>
