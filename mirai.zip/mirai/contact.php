<?php include("includes/header.php"); ?>
<h1>Contact Us</h1>
<p>Email: contact@miraiholdings.local</p>
<p>Phone: 03-1234-5678</p>
<?php include("includes/footer.php"); ?>
