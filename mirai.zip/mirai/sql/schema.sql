CREATE DATABASE mirai_db;
CREATE USER 'mirai_user'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON mirai_db.* TO 'mirai_user'@'localhost';

CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    requested_amount DECIMAL(15,2),
    status VARCHAR(20) DEFAULT 'Pending',
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
