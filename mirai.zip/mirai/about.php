<?php include("includes/header.php"); ?>
<h1>About Us</h1>
<p>Mirai Holdings is committed to delivering financial excellence through diversified investment portfolios and strategic partnerships.</p>
<?php include("includes/footer.php"); ?>
