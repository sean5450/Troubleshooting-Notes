<?php include("includes/header.php"); ?>
<main>
  <img src="/assets/images/banner.jpg" alt="Clean Energy Banner" style="width: 100%; height: auto;">
  <h2>Welcome to Nihon Hatsuden Giken</h2>
  <p>Leading innovations in clean energy technologies.</p>
</main>
<?php include("includes/footer.php"); ?>