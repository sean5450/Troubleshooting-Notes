<?php include("includes/header.php"); ?>
<main>
  <h2>Department Directory</h2>
  <ul>
    <li><strong>Advanced Energy Systems Research</strong> – 03-6800-1011</li>
    <li><strong>Renewable Energy Integration</strong> – 03-6800-1022</li>
    <li><strong>Energy Storage and Conversion</strong> – 03-6800-1033</li>
    <li><strong>Materials Science</strong> – 03-6800-1044</li>
    <li><strong>Smart Grid and Infrastructure Innovation</strong> – 03-6800-1055</li>
    <li><strong>Sustainability and Environmental Impact</strong> – 03-6800-1066</li>
    <li><strong>Industrial Partnerships and Technology Transfer</strong> – 03-6800-1077</li>
    <li><strong>Policy, Regulation, and Energy Economics</strong> – 03-6800-1088</li>
    <li><strong>Education, Outreach, and Workforce Development</strong> – 03-6800-1099</li>
    <li><strong>Systems Engineering and Simulation</strong> – 03-6800-1100</li>
  </ul>
</main>
<?php include("includes/footer.php"); ?>