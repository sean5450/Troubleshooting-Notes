<?php include("includes/header.php"); ?>
<main>
  <h2>Contact Us</h2>
  <p>Email: contact@hatsuden.org</p>
</main>
<?php include("includes/footer.php"); ?>