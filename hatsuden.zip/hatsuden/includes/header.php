<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Nihon Hatsuden Giken</title>
  <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
  <header>
    <h1>Nihon Hatsuden Giken</h1>
    <nav>
      <a href="/index.php">Home</a>
      <a href="/mission.php">Mission</a>
      <a href="/projects.php">Projects</a>
      <a href="/directory.php">Directory</a>
      <a href="/contact.php">Contact</a>
    </nav>
  </header>