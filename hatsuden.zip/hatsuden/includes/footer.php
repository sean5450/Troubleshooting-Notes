
  <footer>
    <p>&copy; 2025 Nihon Hatsuden Giken</p>
  </footer>
</body>
</html>