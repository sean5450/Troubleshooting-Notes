<?php
$USERNAME = 'admin';
$PASSWORD = 'giken2025';

if (!isset($_SERVER['PHP_AUTH_USER']) || $_SERVER['PHP_AUTH_USER'] !== $USERNAME || $_SERVER['PHP_AUTH_PW'] !== $PASSWORD) {
  header('WWW-Authenticate: Basic realm="Admin Area"');
  header('HTTP/1.0 401 Unauthorized');
  echo 'Unauthorized';
  exit;
}

function saveFile($file, $content) {
  file_put_contents($file, $content);
}

$mission_file = dirname(__DIR__) . "/nihon_hatsuden_giken_site/mission.php";
$directory_file = dirname(__DIR__) . "/nihon_hatsuden_giken_site/directory.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (isset($_POST["mission"])) {
    $mission_content = '<?php include("includes/header.php"); ?>
<main>
<h2>Our Mission</h2>
<p>' . htmlentities($_POST["mission"]) . '</p>
</main>
<?php include("includes/footer.php"); ?>';
    saveFile($mission_file, $mission_content);
  }
  if (isset($_POST["directory"])) {
    $directory_content = '<?php include("includes/header.php"); ?>
<main>
<h2>Department Directory</h2>
<ul>' . htmlentities($_POST["directory"]) . '</ul>
</main>
<?php include("includes/footer.php"); ?>';
    saveFile($directory_file, $directory_content);
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Panel</title>
</head>
<body>
  <h1>Admin Panel</h1>

  <h2>Edit Mission Statement</h2>
  <form method="post">
    <textarea name="mission" rows="8" cols="80">At Nihon Hatsuden Giken, our mission is to advance the science and engineering of clean energy systems through rigorous research, collaborative innovation, and real-world application. We are committed to developing sustainable, efficient, and resilient power technologies that reduce environmental impact, support energy independence, and shape a cleaner future for generations to come.</textarea><br>
    <input type="submit" value="Save Mission">
  </form>

  <h2>Edit Department Directory (HTML list items)</h2>
  <form method="post">
    <textarea name="directory" rows="10" cols="80">
<li><strong>Advanced Energy Systems Research</strong> – 03-6800-1011</li>
<li><strong>Renewable Energy Integration</strong> – 03-6800-1022</li>
<li><strong>Energy Storage and Conversion</strong> – 03-6800-1033</li>
<li><strong>Materials Science</strong> – 03-6800-1044</li>
<li><strong>Smart Grid and Infrastructure Innovation</strong> – 03-6800-1055</li>
<li><strong>Sustainability and Environmental Impact</strong> – 03-6800-1066</li>
<li><strong>Industrial Partnerships and Technology Transfer</strong> – 03-6800-1077</li>
<li><strong>Policy, Regulation, and Energy Economics</strong> – 03-6800-1088</li>
<li><strong>Education, Outreach, and Workforce Development</strong> – 03-6800-1099</li>
<li><strong>Systems Engineering and Simulation</strong> – 03-6800-1100</li>
    </textarea><br>
    <input type="submit" value="Save Directory">
  </form>
</body>
</html>
