<?php include("includes/header.php"); ?>
<main>
<h2>Our Projects</h2>

  <section style="margin-bottom: 2em;">
    <img src="/assets/images/solar_project.jpg" alt="Solar Grid Integration" style="max-width: 300px; float: right; margin-left: 20px;">
    <h3>Solar Grid Integration</h3>
    <p><strong>Timeline:</strong> 2025–2028</p>
    <p>Research and pilot implementation of next-gen solar PV systems integrated with distributed grid controllers.</p>
    <div style="clear: both;"></div>
  </section>

  <section style="margin-bottom: 2em;">
    <img src="/assets/images/wind_project.jpg" alt="Offshore Wind Optimization" style="max-width: 300px; float: right; margin-left: 20px;">
    <h3>Offshore Wind Optimization</h3>
    <p><strong>Timeline:</strong> 2026–2030</p>
    <p>Simulation and deployment of advanced offshore turbines with AI-based wind forecasting.</p>
    <div style="clear: both;"></div>
  </section>

  <section style="margin-bottom: 2em;">
    <img src="/assets/images/hydrogen_project.jpg" alt="Hydrogen Fuel Storage" style="max-width: 300px; float: right; margin-left: 20px;">
    <h3>Hydrogen Fuel Storage</h3>
    <p><strong>Timeline:</strong> 2027–2032</p>
    <p>Development of high-density hydrogen storage modules for industrial transport and grid buffering.</p>
    <div style="clear: both;"></div>
  </section>

  <section style="margin-bottom: 2em;">
    <img src="/assets/images/battery_project.jpg" alt="Grid-Scale Battery Research" style="max-width: 300px; float: right; margin-left: 20px;">
    <h3>Grid-Scale Battery Research</h3>
    <p><strong>Timeline:</strong> 2028–2035</p>
    <p>Battery chemistries and configurations for load balancing and renewable intermittency.</p>
    <div style="clear: both;"></div>
  </section>

  <section style="margin-bottom: 2em;">
    <img src="/assets/images/smartgrid_project.jpg" alt="Smart Grid and Infrastructure AI" style="max-width: 300px; float: right; margin-left: 20px;">
    <h3>Smart Grid and Infrastructure AI</h3>
    <p><strong>Timeline:</strong> 2029–2040</p>
    <p>Dynamic grid automation using real-time analytics and self-healing networks.</p>
    <div style="clear: both;"></div>
  </section>
</main>
<?php include("includes/footer.php"); ?>