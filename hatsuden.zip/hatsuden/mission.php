<?php include("includes/header.php"); ?>
<main>
  <h2>Our Mission</h2>
  <p>At Nihon Hatsuden Giken, our mission is to advance the science and engineering of clean energy systems through rigorous research, collaborative innovation, and real-world application. We are committed to developing sustainable, efficient, and resilient power technologies that reduce environmental impact, support energy independence, and shape a cleaner future for generations to come.</p>
</main>
<?php include("includes/footer.php"); ?>